# internshala-lifestyle-store.
#make sure giving the correct image location.
#it contains only html and css.
